"""
Create a sample Excel file for testing
Run this file first to generate test data
"""

import pandas as pd
import numpy as np

# Create sample data
np.random.seed(42)  # For reproducible results

data = {
    'Name': ['John Smith', 'Sarah Johnson', 'Mike Brown', 'Emma Davis', 'Tom Wilson',
             'Lisa Anderson', 'Robert Taylor', 'Maria Garcia', 'James Martinez', 'Linda Rodriguez',
             'David Lee', 'Jennifer White'],
    
    'Department': ['Sales', 'Marketing', 'Sales', 'HR', 'IT',
                   'Marketing', 'Sales', 'HR', 'IT', 'Sales',
                   'Marketing', 'HR'],
    
    'Age': [28, 34, 45, 29, 38, 
            31, 42, 26, 35, 41,
            33, np.nan],  # One missing value
    
    'Salary': [50000, 65000, 75000, 55000, 85000,
               62000, 78000, 52000, 90000, 71000,
               64000, 58000],
    
    'Years_Experience': [3, 8, 15, 4, 10,
                         6, 12, 2, 9, 11,
                         5, 7],
    
    'Performance_Score': [85, 92, 78, 88, 95,
                          89, 82, 90, 94, 87,
                          91, 86],
    
    'City': ['New York', 'Los Angeles', 'Chicago', 'Houston', 'Phoenix',
             'Philadelphia', 'San Antonio', 'San Diego', 'Dallas', 'Austin',
             'Boston', 'Denver']
}

# Add some duplicate rows for testing
data_duplicate = data.copy()
data_duplicate['Name'].append('John Smith')  # Duplicate name
data_duplicate['Department'].append('Sales')
data_duplicate['Age'].append(28)
data_duplicate['Salary'].append(50000)
data_duplicate['Years_Experience'].append(3)
data_duplicate['Performance_Score'].append(85)
data_duplicate['City'].append('New York')

# Create DataFrame
df = pd.DataFrame(data)

# Save to Excel
df.to_excel('sample_data.xlsx', index=False)
print("✅ Sample Excel file 'sample_data.xlsx' created successfully!")
print(f"📊 Created {len(df)} rows of sample data")
print("\nSample data preview:")
print(df.head(10))
print("\nColumn information:")
print(df.info())