"""
Excel Data Cleaning & Analysis Tool
Author: Hina Rashid
Description: A complete tool to clean, analyze, and process Excel files
"""

import pandas as pd
import matplotlib.pyplot as plt
import os
from datetime import datetime

class ExcelDataTool:
    """
    Main class for Excel data processing
    """
    
    def __init__(self):
        """Initialize the tool with empty data"""
        self.data = None  # This will store our DataFrame
        self.file_name = None
        self.cleaning_steps = []  # Track cleaning operations
        
    def load_excel_file(self, file_path):
        """
        Load an Excel file into pandas DataFrame
        
        Args:
            file_path (str): Path to the Excel file
        """
        try:
            # Check if file exists
            if not os.path.exists(file_path):
                raise FileNotFoundError(f"File not found: {file_path}")
            
            # Check file extension
            if not file_path.endswith(('.xlsx', '.xls')):
                raise ValueError("Only Excel files (.xlsx or .xls) are supported")
            
            # Load the Excel file
            self.data = pd.read_excel(file_path)
            self.file_name = file_path
            
            print(f"✅ Successfully loaded: {file_path}")
            print(f"📊 Shape: {self.data.shape[0]} rows × {self.data.shape[1]} columns")
            print(f"📋 Columns: {list(self.data.columns)}")
            
            # Show first few rows
            print("\n🔍 First 5 rows of data:")
            print(self.data.head())
            
            return True
            
        except Exception as e:
            print(f"❌ Error loading file: {e}")
            return False
    
    def show_data_info(self):
        """Display detailed information about the data"""
        if self.data is None:
            print("⚠️ No data loaded. Please load an Excel file first.")
            return
        
        print("\n" + "="*50)
        print("📊 DATA INFORMATION")
        print("="*50)
        
        print(f"Total Records: {len(self.data)}")
        print(f"Total Columns: {len(self.data.columns)}")
        
        print("\n📋 Column Information:")
        for col in self.data.columns:
            print(f"  • {col}: {self.data[col].dtype}")
        
        print("\n🔢 Missing Values:")
        missing = self.data.isnull().sum()
        for col, count in missing.items():
            if count > 0:
                print(f"  • {col}: {count} missing values")
        
        print("\n📈 Numeric Columns Statistics:")
        numeric_cols = self.data.select_dtypes(include=['number']).columns
        if len(numeric_cols) > 0:
            for col in numeric_cols:
                print(f"\n  📊 {col}:")
                print(f"    Mean: {self.data[col].mean():.2f}")
                print(f"    Median: {self.data[col].median():.2f}")
                print(f"    Max: {self.data[col].max():.2f}")
                print(f"    Min: {self.data[col].min():.2f}")
                print(f"    Std Dev: {self.data[col].std():.2f}")
        else:
            print("  No numeric columns found")
    
    def clean_data(self):
        """
        Clean the data by:
        1. Standardizing column names
        2. Removing duplicates
        3. Handling missing values
        """
        if self.data is None:
            print("⚠️ No data loaded. Please load an Excel file first.")
            return
        
        print("\n" + "="*50)
        print("🧹 DATA CLEANING")
        print("="*50)
        
        # Step 1: Standardize column names
        print("\n1️⃣ Standardizing column names...")
        original_cols = self.data.columns.tolist()
        self.data.columns = self.data.columns.str.strip().str.lower().str.replace(' ', '_')
        self.data.columns = self.data.columns.str.replace('[^a-z0-9_]', '', regex=True)
        print(f"   Original: {original_cols}")
        print(f"   New: {list(self.data.columns)}")
        self.cleaning_steps.append("Standardized column names")
        
        # Step 2: Remove duplicates
        print("\n2️⃣ Removing duplicate rows...")
        initial_rows = len(self.data)
        self.data = self.data.drop_duplicates()
        removed_duplicates = initial_rows - len(self.data)
        print(f"   Removed {removed_duplicates} duplicate rows")
        self.cleaning_steps.append(f"Removed {removed_duplicates} duplicate rows")
        
        # Step 3: Handle missing values
        print("\n3️⃣ Handling missing values...")
        print("   Options:")
        print("   1. Fill with mean (for numeric columns)")
        print("   2. Fill with median (for numeric columns)")
        print("   3. Fill with custom value")
        print("   4. Drop rows with missing values")
        print("   5. Drop columns with too many missing values")
        
        choice = input("\n   Choose an option (1-5): ").strip()
        
        if choice == '1':
            # Fill numeric columns with mean
            numeric_cols = self.data.select_dtypes(include=['number']).columns
            for col in numeric_cols:
                self.data[col].fillna(self.data[col].mean(), inplace=True)
            print(f"   ✅ Filled numeric columns with mean values")
            self.cleaning_steps.append("Filled missing numeric values with mean")
            
        elif choice == '2':
            # Fill numeric columns with median
            numeric_cols = self.data.select_dtypes(include=['number']).columns
            for col in numeric_cols:
                self.data[col].fillna(self.data[col].median(), inplace=True)
            print(f"   ✅ Filled numeric columns with median values")
            self.cleaning_steps.append("Filled missing numeric values with median")
            
        elif choice == '3':
            # Fill with custom value
            custom_value = input("   Enter custom value: ")
            for col in self.data.columns:
                if self.data[col].dtype in ['float64', 'int64']:
                    try:
                        self.data[col].fillna(float(custom_value), inplace=True)
                    except:
                        self.data[col].fillna(custom_value, inplace=True)
                else:
                    self.data[col].fillna(custom_value, inplace=True)
            print(f"   ✅ Filled missing values with '{custom_value}'")
            self.cleaning_steps.append(f"Filled missing values with '{custom_value}'")
            
        elif choice == '4':
            # Drop rows with missing values
            before = len(self.data)
            self.data = self.data.dropna()
            after = len(self.data)
            print(f"   ✅ Dropped {before - after} rows with missing values")
            self.cleaning_steps.append(f"Dropped {before - after} rows with missing values")
            
        elif choice == '5':
            # Drop columns with high missing percentage
            threshold = float(input("   Drop columns with >__% missing (enter number 0-100): "))
            threshold = threshold / 100
            before_cols = len(self.data.columns)
            self.data = self.data.loc[:, self.data.isnull().mean() < threshold]
            after_cols = len(self.data.columns)
            print(f"   ✅ Dropped {before_cols - after_cols} columns")
            self.cleaning_steps.append(f"Dropped columns with >{threshold*100}% missing")
            
        else:
            print("   ℹ️ No changes made to missing values")
        
        print("\n✅ Data cleaning complete!")
        print(f"📊 Final shape: {self.data.shape}")
        
    def analyze_data(self):
        """Perform advanced data analysis"""
        if self.data is None:
            print("⚠️ No data loaded. Please load an Excel file first.")
            return
        
        print("\n" + "="*50)
        print("📈 ADVANCED DATA ANALYSIS")
        print("="*50)
        
        # Basic statistics
        print("\n1️⃣ BASIC STATISTICS:")
        print(self.data.describe())
        
        # Group by analysis - if there are categorical columns
        print("\n2️⃣ GROUP BY ANALYSIS:")
        categorical_cols = self.data.select_dtypes(include=['object']).columns
        
        if len(categorical_cols) > 0:
            print(f"   Categorical columns found: {list(categorical_cols)}")
            
            # Let user choose a column to group by
            print("\n   Columns available for grouping:")
            for i, col in enumerate(categorical_cols, 1):
                value_counts = self.data[col].nunique()
                print(f"   {i}. {col} ({value_counts} unique values)")
            
            choice = input("\n   Enter column number to group by (or 0 to skip): ").strip()
            
            if choice.isdigit() and int(choice) > 0:
                idx = int(choice) - 1
                if 0 <= idx < len(categorical_cols):
                    group_col = categorical_cols[idx]
                    
                    # Group by the selected column
                    numeric_cols = self.data.select_dtypes(include=['number']).columns
                    
                    if len(numeric_cols) > 0:
                        print(f"\n   Grouping by '{group_col}':")
                        grouped = self.data.groupby(group_col)[numeric_cols].mean()
                        print(grouped)
                        
                        # Ask if user wants to save this analysis
                        save_choice = input("\n   Save this grouped analysis to CSV? (y/n): ").strip().lower()
                        if save_choice == 'y':
                            filename = f"grouped_analysis_{group_col}.csv"
                            grouped.to_csv(filename)
                            print(f"   ✅ Saved to {filename}")
        else:
            print("   No categorical columns found. Group analysis not available.")
        
        # Correlation analysis for numeric data
        numeric_cols = self.data.select_dtypes(include=['number']).columns
        if len(numeric_cols) >= 2:
            print("\n3️⃣ CORRELATION ANALYSIS:")
            correlation = self.data[numeric_cols].corr()
            print(correlation)
            
            # Optional: Create correlation heatmap
            viz_choice = input("\n   Create correlation heatmap? (y/n): ").strip().lower()
            if viz_choice == 'y':
                plt.figure(figsize=(10, 8))
                plt.imshow(correlation, cmap='coolwarm', aspect='auto')
                plt.colorbar()
                plt.xticks(range(len(numeric_cols)), numeric_cols, rotation=45)
                plt.yticks(range(len(numeric_cols)), numeric_cols)
                plt.title('Correlation Heatmap')
                plt.tight_layout()
                plt.show()
    
    def filter_and_search(self):
        """Filter and search data based on user criteria"""
        if self.data is None:
            print("⚠️ No data loaded. Please load an Excel file first.")
            return
        
        print("\n" + "="*50)
        print("🔍 FILTER & SEARCH")
        print("="*50)
        
        print("1. Search for value in specific column")
        print("2. Filter rows by condition (e.g., Age > 30)")
        print("3. Show unique values in a column")
        print("4. Export filtered data")
        
        choice = input("\nChoose option (1-4): ").strip()
        
        if choice == '1':
            # Search for value
            print(f"\nAvailable columns: {list(self.data.columns)}")
            column = input("Enter column name: ").strip()
            
            if column not in self.data.columns:
                print("❌ Column not found!")
                return
            
            search_value = input("Enter value to search: ").strip()
            
            # Case-insensitive search
            if self.data[column].dtype == 'object':
                result = self.data[self.data[column].str.lower() == search_value.lower()]
            else:
                result = self.data[self.data[column] == search_value]
            
            print(f"\n✅ Found {len(result)} matching records")
            if len(result) > 0:
                print(result)
                
                # Option to save results
                save_choice = input("\nSave search results? (y/n): ").strip().lower()
                if save_choice == 'y':
                    filename = f"search_results_{search_value}.csv"
                    result.to_csv(filename, index=False)
                    print(f"✅ Saved to {filename}")
        
        elif choice == '2':
            # Filter by condition
            print(f"\nAvailable columns: {list(self.data.columns)}")
            print("\nExample conditions:")
            print("  - Age > 30")
            print("  - Sales < 1000")
            print("  - Name == 'John'")
            
            condition = input("\nEnter condition: ").strip()
            
            try:
                filtered_data = self.data.query(condition)
                print(f"\n✅ {len(filtered_data)} records match the condition")
                if len(filtered_data) > 0:
                    print(filtered_data)
                    
                    # Option to save results
                    save_choice = input("\nSave filtered data? (y/n): ").strip().lower()
                    if save_choice == 'y':
                        filename = "filtered_data.csv"
                        filtered_data.to_csv(filename, index=False)
                        print(f"✅ Saved to {filename}")
            except Exception as e:
                print(f"❌ Invalid condition: {e}")
        
        elif choice == '3':
            # Show unique values
            print(f"\nAvailable columns: {list(self.data.columns)}")
            column = input("Enter column name: ").strip()
            
            if column not in self.data.columns:
                print("❌ Column not found!")
                return
            
            unique_values = self.data[column].unique()
            print(f"\n📋 Unique values in '{column}':")
            for value in unique_values[:20]:  # Show first 20
                count = self.data[self.data[column] == value].shape[0]
                print(f"  • {value}: {count} records")
            
            if len(unique_values) > 20:
                print(f"  ... and {len(unique_values) - 20} more values")
        
        elif choice == '4':
            # Export filtered data (allows custom filtering first)
            print("Export current data as filtered result?")
            confirm = input("Current data will be saved to filtered_data.csv (y/n): ").strip().lower()
            if confirm == 'y':
                filename = "filtered_data.csv"
                self.data.to_csv(filename, index=False)
                print(f"✅ Saved current data to {filename}")
    
    def save_results(self):
        """Save cleaned data and generate reports"""
        if self.data is None:
            print("⚠️ No data to save. Please load and clean data first.")
            return
        
        print("\n" + "="*50)
        print("💾 SAVE RESULTS")
        print("="*50)
        
        # Save cleaned data
        print("\n1️⃣ SAVE CLEANED DATA:")
        print("   Options:")
        print("   1. Excel format (.xlsx)")
        print("   2. CSV format (.csv)")
        
        format_choice = input("\n   Choose format (1-2): ").strip()
        
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        
        if format_choice == '1':
            filename = f"cleaned_data_{timestamp}.xlsx"
            self.data.to_excel(filename, index=False)
            print(f"   ✅ Saved cleaned data to {filename}")
        else:
            filename = f"cleaned_data_{timestamp}.csv"
            self.data.to_csv(filename, index=False)
            print(f"   ✅ Saved cleaned data to {filename}")
        
        # Generate summary report
        print("\n2️⃣ GENERATING SUMMARY REPORT:")
        
        report_filename = f"analysis_report_{timestamp}.txt"
        with open(report_filename, 'w') as report:
            report.write("="*60 + "\n")
            report.write("DATA ANALYSIS REPORT\n")
            report.write(f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
            report.write("="*60 + "\n\n")
            
            report.write("1. DATA OVERVIEW\n")
            report.write("-"*30 + "\n")
            report.write(f"Original file: {self.file_name}\n")
            report.write(f"Total records: {len(self.data)}\n")
            report.write(f"Total columns: {len(self.data.columns)}\n\n")
            
            report.write("2. CLEANING STEPS PERFORMED\n")
            report.write("-"*30 + "\n")
            for i, step in enumerate(self.cleaning_steps, 1):
                report.write(f"  {i}. {step}\n")
            report.write("\n")
            
            report.write("3. COLUMN INFORMATION\n")
            report.write("-"*30 + "\n")
            for col in self.data.columns:
                report.write(f"  • {col} ({self.data[col].dtype})\n")
                if self.data[col].dtype in ['float64', 'int64']:
                    report.write(f"      Missing: {self.data[col].isnull().sum()}\n")
                    report.write(f"      Mean: {self.data[col].mean():.2f}\n")
                    report.write(f"      Min: {self.data[col].min():.2f}\n")
                    report.write(f"      Max: {self.data[col].max():.2f}\n")
            report.write("\n")
            
            report.write("4. NUMERIC STATISTICS\n")
            report.write("-"*30 + "\n")
            numeric_cols = self.data.select_dtypes(include=['number']).columns
            if len(numeric_cols) > 0:
                stats = self.data[numeric_cols].describe()
                report.write(stats.to_string())
            else:
                report.write("No numeric columns found\n")
        
        print(f"   ✅ Report saved to {report_filename}")
        
        # Option to save as CSV
        save_csv = input("\n   Save report as CSV as well? (y/n): ").strip().lower()
        if save_csv == 'y':
            csv_report = f"analysis_report_{timestamp}.csv"
            self.data.describe().to_csv(csv_report)
            print(f"   ✅ CSV report saved to {csv_report}")
    
    def create_visualizations(self):
        """Create data visualizations (Bonus feature)"""
        if self.data is None:
            print("⚠️ No data loaded. Please load an Excel file first.")
            return
        
        print("\n" + "="*50)
        print("📊 DATA VISUALIZATION")
        print("="*50)
        
        numeric_cols = self.data.select_dtypes(include=['number']).columns
        
        if len(numeric_cols) == 0:
            print("No numeric columns available for visualization.")
            return
        
        print("\nAvailable numeric columns:")
        for i, col in enumerate(numeric_cols, 1):
            print(f"  {i}. {col}")
        
        print("\nVisualization types:")
        print("  1. Histogram")
        print("  2. Bar Chart")
        print("  3. Line Plot")
        print("  4. Box Plot")
        
        viz_choice = input("\nChoose visualization (1-4): ").strip()
        col_choice = input("Choose column number: ").strip()
        
        try:
            idx = int(col_choice) - 1
            if 0 <= idx < len(numeric_cols):
                column = numeric_cols[idx]
                
                plt.figure(figsize=(10, 6))
                
                if viz_choice == '1':
                    plt.hist(self.data[column].dropna(), bins=20, color='skyblue', edgecolor='black')
                    plt.xlabel(column)
                    plt.ylabel('Frequency')
                    plt.title(f'Histogram of {column}')
                    
                elif viz_choice == '2':
                    # For bar chart, show top 10 values
                    top_values = self.data[column].value_counts().head(10)
                    plt.bar(range(len(top_values)), top_values.values, color='coral')
                    plt.xticks(range(len(top_values)), top_values.index, rotation=45)
                    plt.xlabel(column)
                    plt.ylabel('Count')
                    plt.title(f'Top 10 Values in {column}')
                    
                elif viz_choice == '3':
                    plt.plot(self.data[column].values, color='green', marker='o', linestyle='-', linewidth=1)
                    plt.xlabel('Index')
                    plt.ylabel(column)
                    plt.title(f'Line Plot of {column}')
                    
                elif viz_choice == '4':
                    plt.boxplot(self.data[column].dropna())
                    plt.ylabel(column)
                    plt.title(f'Box Plot of {column}')
                
                plt.grid(True, alpha=0.3)
                plt.tight_layout()
                plt.show()
                
                # Save visualization
                save_choice = input("\nSave this visualization? (y/n): ").strip().lower()
                if save_choice == 'y':
                    filename = f"viz_{column}_{viz_choice}.png"
                    plt.savefig(filename, dpi=300, bbox_inches='tight')
                    print(f"✅ Saved to {filename}")
                
        except Exception as e:
            print(f"❌ Error creating visualization: {e}")
    
    def run_menu(self):
        """Main menu system"""
        while True:
            print("\n" + "="*50)
            print("📊 EXCEL DATA CLEANING & ANALYSIS TOOL")
            print("="*50)
            print("1. 📂 Load Excel File")
            print("2. 🧹 Clean Data")
            print("3. 📈 Analyze Data")
            print("4. 🔍 Filter & Search")
            print("5. 📊 Create Visualizations")
            print("6. 💾 Save Results")
            print("7. ℹ️ Show Data Info")
            print("8. 🚪 Exit")
            print("="*50)
            
            if self.data is not None:
                print(f"📁 Current file: {self.file_name}")
                print(f"📊 Data shape: {self.data.shape}")
            
            choice = input("\nEnter your choice (1-8): ").strip()
            
            if choice == '1':
                file_path = input("Enter Excel file path: ").strip()
                self.load_excel_file(file_path)
                
            elif choice == '2':
                self.clean_data()
                
            elif choice == '3':
                self.analyze_data()
                
            elif choice == '4':
                self.filter_and_search()
                
            elif choice == '5':
                self.create_visualizations()
                
            elif choice == '6':
                self.save_results()
                
            elif choice == '7':
                self.show_data_info()
                
            elif choice == '8':
                print("\n✅ Thank you for using Excel Data Tool!")
                print("👋 Goodbye!")
                break
                
            else:
                print("❌ Invalid choice. Please enter 1-8.")

# Main execution
if __name__ == "__main__":
    # Create an instance of the tool
    tool = ExcelDataTool()
    
    # Run the menu
    tool.run_menu()